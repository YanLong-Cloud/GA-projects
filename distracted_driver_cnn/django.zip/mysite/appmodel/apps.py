from django.apps import AppConfig


class AppmodelConfig(AppConfig):
    name = 'appmodel'
