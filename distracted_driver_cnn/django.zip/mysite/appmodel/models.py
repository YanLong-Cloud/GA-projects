from django.db import models
from django import forms
from tensorflow.keras.models import load_model
from skimage import filters,morphology
import cv2
from scipy.ndimage import label
import numpy as np
import os

APPMODEL_BASE = os.path.dirname(os.path.abspath(__file__))

def make_pred(dir):
    dictionary = {
    0: "0: safe driving",
    1: "1: texting - right",
    2: "2: talking on the phone - right",
    3: "3: texting - left",
    4: "4: talking on the phone - left",
    5: "5: operating the radio",
    6: "6: drinking",
    7: "7: reaching behind",
    8: "8: hair and makeup",
    9: "9: talking to passenger"
    }

    images = cv2.imread(os.path.join(APPMODEL_BASE+'\\images',dir))
    cnn=load_model(os.path.join(APPMODEL_BASE,"cnn.h5"))
    cnn.load_weights(os.path.join(APPMODEL_BASE,"cnn_weights.h5"))
    for channel in range(0,2):
        img = filters.gaussian(images[:,:,channel], sigma=3.0)
        img = filters.sobel(img)
        dark_spots = np.array((img > 2/255).nonzero())
        bool_mask = np.zeros(img.shape, dtype=np.bool)
        bool_mask[tuple(dark_spots)] = 1.
        seed_mask, num_seeds = label(bool_mask)
        ws = morphology.watershed(img, seed_mask)
        # do the watershed on all 3 layers
    images[:,:,channel]=ws*images[:,:,channel]
    images = cv2.resize(images,(256,256),interpolation = cv2.INTER_CUBIC)
    images = images/255.
    images = images.reshape(-1,256,256,3)
    return("{}".format(dictionary[np.argmax(cnn.predict(images))]))

class ImageForm(forms.Form):
    image = forms.ImageField()

class ImageModel(models.Model):
    image = models.ImageField()
    def __str__(self):
        return str(self.image)
