from django.shortcuts import render
from django.http import HttpResponse
from . import models
from django.http import HttpResponse
from keras.models import load_model
from skimage import filters,morphology
import cv2
from scipy.ndimage import label
import numpy as np
import os

# Create your views here.
APPMODEL_BASE = os.path.dirname(os.path.abspath(__file__))

def runmodel(request):
    if request.method == "POST":
        form = models.ImageForm(request.POST,request.FILES)
        if form.is_valid():
            image = form.cleaned_data.get("image")
            obj = models.ImageModel.objects.create(image=image)
            obj.save()
            prediction=models.make_pred(str(obj))
    else:
        prediction = ''
        image=''
        form=models.ImageForm()
    return render(request,'homepage.html',{'form':form,'prediction':prediction,'image':image})
